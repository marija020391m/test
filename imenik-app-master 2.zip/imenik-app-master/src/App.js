import React from 'react';
import './App.css';
import Main from './components/main/Main';

class Item {
  constructor(name, number) {
    this.name = name;
    this.number = number;
  }
};

class App extends React.Component {

  createItem(name, number) {
  let item = new Item(name, number);
  }
  

  render() {
  return (
    <div id="app-container">
      <Main></Main>
    </div>
  );
  }
}

export default App;
