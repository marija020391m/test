import React from "react";
import { useState } from "react";
import './main.css';

const Main = () => {

    const [name, setName] = useState('');  // Set initial state 
    const [number, setNumber] = useState('');

    const [message, setMessage] = useState('');

    const handleSubmit = event => {
        console.log('value is', event.target.value)
        event.preventDefault(); 

        setMessage(`${name} ${number}`);

        // setName('');
        // setNumber('');
    };

    return (
        <div className = "wrap">
            <form onSubmit={handleSubmit}>
                <input type="text"
                id = "name"
                name = "name"
                placeholher = "Your Name"
                onChange={event => setName(event.target.value)}
                value={name} />

                <input type="number"
                id = "number"
                name = "number"
                placeholher = "Your Number"
                onChange={event => setNumber(event.target.value)}
                value={number} />

                <button value = "submit" type="submit">Add</button>

                <h2 className = "showResult">{message} </h2>
            </form>
        </div>
    )
}

export default Main;